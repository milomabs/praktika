﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpressDelivery.Models
{
    //модель доставки
    public class Delivery
    {
        //код доставки
        public int Id { get; set; }
        //код заказчика
        public int Id_customer { get; set; }
        //код курьера
        public int Id_courier { get; set; }
        //адрес отправки
        public string Address { get; set; }
        //статус доставки
        public string Status { get; set; }
        //комментарий заказчика
        public string Comment { get; set; }
        //дата и время создания
        public DateTime Date_Time { get; set; }
        //стоимость доставки
        public int Price { get; set; }
    }
}
