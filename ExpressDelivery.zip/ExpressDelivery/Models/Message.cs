﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpressDelivery.Models
{
    //модель сообщений
    public class Message
    {
        //код сообщения
        public int Id { get; set; }
        //код доставки
        public int Id_delivery { get; set; }
        //код отправителя
        public int Id_sender { get; set; }
        //код получателя
        public int Id_recipient { get; set; }
        //текст сообщения
        public string Text { get; set; }
        //прикрепленное изображения
        public byte[] Photo { get; set; }
        //дата и время отправки
        public DateTime Date_Time { get; set; }
    }
}
