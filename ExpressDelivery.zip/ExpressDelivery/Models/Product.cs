﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpressDelivery.Models
{
    //модель объекта доставки
    public class Product
    {
        //код объекта
        public int Id { get; set; }
        //фотография объекта
        public byte[] Photo { get; set; }
        //вес
        public int Weight { get; set; }
        //комментарий к доставке
        public string Comment { get; set; }
        //номер телефона получателя
        public string Phone_user { get; set; }
        //адрес доставки
        public string Address { get; set; }
        //статус доставки
        public string Status { get; set; }
        //код доставки
        public int Id_delivery { get; set; }
    }
}
