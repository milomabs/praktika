﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpressDelivery.Models
{
    //модель пользователя
    public class User
    {
        //код пользователя
        public int Id { get; set; }
        //фамилия имя отчество
        public string FIO { get; set; }
        //фотография
        public byte[] Photo { get; set; }
        //номер телефона
        public string Phone { get; set; }
        //адрес
        public string Address { get; set; }
        //роль
        public bool Role { get; set; }
        //пароль
        public string Password { get; set; }
    }
}
