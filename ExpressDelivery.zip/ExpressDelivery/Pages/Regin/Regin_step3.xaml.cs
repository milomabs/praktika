﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using System.Text.RegularExpressions;

namespace ExpressDelivery.Pages.Regin
{
    /// <summary>
    /// Логика взаимодействия для Regin_step3.xaml
    /// </summary>
    public partial class Regin_step3 : Page
    {
        //новый пользователь
        User newUser = new User();
        public Regin_step3(User NewUser)
        {
            InitializeComponent();
            //задаем данные пользователя
            newUser = NewUser;
        }
        private void Next(object sender, RoutedEventArgs e)
        {
            //город
            string city = TbCity.Text;
            //улица
            string street = TbStreet.Text;
            //новмер дома
            string building = TbBuilding.Text;
            //подъезд
            string entrance = TbEntrance.Text;
            //этаж
            string floor = TbFloor.Text;
            //квартира
            string flat = TbFlat.Text;
            //проверяем данные на соответствие формату
            Match match = Regex.Match(city, "^[а-яА-Я \\-]+$");
            Match match1 = Regex.Match(street, "^[0-9а-яА-Я \\-]+$");
            Match match2 = Regex.Match(building, "^[0-9а-яА-Я]+$");
            Match match3 = Regex.Match(entrance, "^[0-9]{0,3}$");
            Match match4 = Regex.Match(floor, "^[0-9]{0,3}$");
            Match match5 = Regex.Match(flat, "^[0-9]{0,3}$");
            //сообщениия об ошибках в случае, если каки-либо данные введены не верно
            if (!match.Success) Message.Text = "Корректно укажите название города!";
            else if (!match1.Success) Message.Text = "Корректно укажите название улицы!";
            else if (!match2.Success) Message.Text = "Корректно укажите номер дома!";
            else if (!match3.Success) Message.Text = "Корректно укажите номер этажа!";
            else if (!match4.Success) Message.Text = "Корректно укажите номер подъезда!";
            else if (!match5.Success) Message.Text = "Корректно укажите номер квартира!";
            else
            {
                //сливаем все данные в одну строку
                string address = $"г.{city}, ул.{street}, д.{building}";
                if (entrance != "") address += $", п.{entrance}";
                if (floor != "") address += $", э.{floor}";
                if (flat != "") address += $", кв.{flat}";
                //задаем пользователю адрес
                newUser.Address = address;
                //переход на следующий этап
                MainWindow.init.OpenPages(new Regin_step4(newUser));
            }
        }
        //очистка блока для сообщений об ошибках
        private void Remove(object sender, MouseEventArgs e)
        {
            Message.Text = "";
        }
    }
}
