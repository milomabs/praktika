﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Context;
using ExpressDelivery.Models;
using System.Text.RegularExpressions;
using Microsoft.Win32;
using Imaging = Aspose.Imaging;
using System.IO;

namespace ExpressDelivery.Pages.Regin
{
    /// <summary>
    /// Логика взаимодействия для Regin_step2.xaml
    /// </summary>
    public partial class Regin_step2 : Page
    {
        //файловый диалог
        OpenFileDialog FileDialogImage = new OpenFileDialog();
        //проверка на указание изображения
        bool BSetImages = false;
        //список всех пользователей системы
        public UsersContext AllUsers = new UsersContext();
        //новый пользователь
        public User newUser = new User();
        public Regin_step2(User NewUser)
        {
            InitializeComponent();
            //данные о новом пользователе
            newUser = NewUser;
            //поддерживаемые типы файлов
            FileDialogImage.Filter = "PNG (*.png)|.png|JPG (*.jpg)|*.jpg";
            //значение сохранения директории
            FileDialogImage.RestoreDirectory = true;
            //название диалогового окна
            FileDialogImage.Title = "Выберите фото";
        }
        //переход на следующий этап регистрации
        private void Next(object sender, RoutedEventArgs e)
        {
            //ФИО из поля ввода
            string FIO = TbFIO.Text;
            //проверка на соответствие формату
            Match match = Regex.Match(FIO, "^[а-я А-Я]+$");
            //сообщение об ошибке в случае несоответствия формату
            if (!match.Success)
                Message.Text = "ФИО должно содержать только кириллицу и пробелы!";
            else
            {
                //добавление данных о ФИО пользователя
                newUser.FIO = FIO;
                //добавление фотографии пользователя, если оно указано
                if (BSetImages)
                    newUser.Photo = File.ReadAllBytes(Directory.GetCurrentDirectory() + @"\IUser.jpg");
                //переход на следующий этап
                MainWindow.init.OpenPages(new Regin_step3(newUser));
            }
        }
        //очистка блока для вывода сообщений об ошибках
        private void Remove(object sender, MouseEventArgs e)
        {
            Message.Text = "";
        }
        //выбор изображения пользователя
        private void SelectImage(object sender, MouseButtonEventArgs e)
        {
            //если статус диалогового окна true
            if (FileDialogImage.ShowDialog() == true)
            {
                //конвертирование размера изображения
                using (Imaging.Image image = Imaging.Image.Load(FileDialogImage.FileName))
                {
                    //ширина изображения
                    int NewWidth = 0;
                    //высота изображения
                    int NewHeight = 0;
                    //проверка сторон изображения
                    if (image.Width > image.Height)
                    {
                        //новая ширина относительно высоты
                        NewWidth = (int)(image.Width * (256f / image.Height));
                        //новая высота
                        NewHeight = 256;
                    }
                    else
                    {
                        //новая ширина
                        NewWidth = 256;
                        //новая высота относительно ширины
                        NewHeight = (int)(image.Height * (256f / image.Width));
                    }
                    //задаем новые размеры
                    image.Resize(NewWidth, NewHeight);
                    //сохранение изображения
                    image.Save("IUser.jpg");
                }
                //обрезка изображения
                using (Imaging.RasterImage rasterImage = (Imaging.RasterImage)Imaging.Image.Load("IUser.jpg"))
                {
                    //кэширование изображения
                    if (!rasterImage.IsCached)
                    {
                        rasterImage.CacheData();
                    }
                    //X
                    int X = 0;
                    //новая ширина
                    int Width = 256;
                    //Y
                    int Y = 0;
                    //новая высота
                    int Height = 256;
                    //если ширина больше
                    if (rasterImage.Width > rasterImage.Height)
                        //задаем X как середину
                        X = (int)((rasterImage.Width - 256f) / 2);
                    else
                        //если высота больше, задаем Y как середину
                        Y = (int)((rasterImage.Height - 256f) / 2);
                    //экземпляр Rectangle нужного размера
                    Imaging.Rectangle rectangle = new Imaging.Rectangle(X, Y, Width, Height);
                    //обрезка изображения
                    rasterImage.Crop(rectangle);
                    //сохранение
                    rasterImage.Save("IUser.jpg");
                }
                //устанавливаем изображение
                IUser.Source = new BitmapImage(new Uri(Directory.GetCurrentDirectory() + @"\IUser.jpg"));
                //изображение указано
                BSetImages = true;
            }
            else
                //изображение не указано
                BSetImages = false;
        }
    }
}
