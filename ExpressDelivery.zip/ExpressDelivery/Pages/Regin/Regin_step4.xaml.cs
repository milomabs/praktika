﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using System.Text.RegularExpressions;

namespace ExpressDelivery.Pages.Regin
{
    /// <summary>
    /// Логика взаимодействия для Regin_step4.xaml
    /// </summary>
    public partial class Regin_step4 : Page
    {
        //список всех полльзователей системы
        public UsersContext AllUsers = new UsersContext();
        //новый пользователь
        public User newUser = new User();
        public Regin_step4(User NewUser)
        {
            InitializeComponent();
            //задаем данные пользователя
            newUser = NewUser;
        }
        //регистрация пользователя
        private void Regin(object sender, RoutedEventArgs e)
        {
            //пароль из поля ввода
            string pwd = TbRwd.Text;
            //повторение пароля из поля ввода
            string repeat = TbRepeat.Text;
            //проверка на соответствие формату
            Match match = Regex.Match(pwd, "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\\W).{5,15}$");
            //сообщение об ошибке в случае несоответствия формату
            if (!match.Success) Message.Text = "Пароль должен содержать: \nодну заглавную и строчную букву\nодин специальный символ\nодну цифру\nот 5 ддо 15 символов";
            //сообщение об ошибке в случае, если пароли не совпадают
            else if (pwd != repeat) Message.Text = "Пароли не совпадают!";
            else
            {
                //если пароли сопали, задаем пароль пользователя
                newUser.Password = pwd;
                //проверяем чек-бокс для выбора роли и задаем пользователю роль
                if (TbRole.IsChecked == true)
                    newUser.Role = true;
                else newUser.Role = false;
                //добавляем пользователя
                AllUsers.Users.Add(newUser);
                //сохраняем изменения
                AllUsers.SaveChanges();
                foreach (User user in AllUsers.Users)
                    if(user.Phone == newUser.Phone)
                        MainWindow.init.activeUser = newUser;
                //переход на главную страницу в зависимости от роли
                if (newUser.Role) MainWindow.init.OpenPages(new Courier.Main());
                else MainWindow.init.OpenPages(new Customer.Main());
            }
        }
        //очитска блока для вывода сообщений об ошибках
        private void Remove(object sender, MouseEventArgs e)
        {
            Message.Text = "";
        }
    }
}
