﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Context;
using ExpressDelivery.Models;
using System.Text.RegularExpressions;

namespace ExpressDelivery.Pages.Regin
{
    /// <summary>
    /// Логика взаимодействия для Regin_step1.xaml
    /// </summary>
    public partial class Regin_step1 : Page
    {
        //список всех пользователей системы
        public UsersContext AllUsers = new UsersContext();
        public Regin_step1()
        {
            InitializeComponent();
        }

        //переход на следующий этап регистрации
        private void Next(object sender, RoutedEventArgs e)
        {
            //номер телефона из поля ввода
            string phone = TbPhone.Text; 
            //проверка соответствия формату
            Match match = Regex.Match(phone, "^\\+7[0-9]{10}$");
            //сообщение об ошибке в случае неверного номера телефона
            if (!match.Success)
                Message.Text = "Укажите номер телефона верно!";
            else
            {
                User user = null;
                //поиск пользователя по номеру телефона в БД
                foreach (User item in AllUsers.Users)
                    if (item.Phone == phone) user = item;
                //сообщение об ошибке в случае если пользователь с таким номером уже существует
                if(user != null)
                    Message.Text = "Пользователь с таким номером уже существует!";
                else
                {
                    //создание нового пользователя
                    User newUser = new User()
                    {
                        Phone = phone
                    };
                    //переход на следующий этап
                    MainWindow.init.OpenPages(new Regin_step2(newUser));
                }
            }
        }

        //очистка блока для вывода сообщений об ошибках
        private void Remove(object sender, MouseEventArgs e)
        {
            Message.Text = "";
        }

        private void Back(object sender, MouseButtonEventArgs e)
        {
            MainWindow.init.OpenPages(new Login());
        }
    }
}
