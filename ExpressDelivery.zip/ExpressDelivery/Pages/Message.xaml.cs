﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using Microsoft.Win32;
using Imaging = Aspose.Imaging;
using System.IO;
using System.Diagnostics;

namespace ExpressDelivery.Pages
{
    /// <summary>
    /// Логика взаимодействия для Message.xaml
    /// </summary>
    public partial class Message : Page
    {
        OpenFileDialog FileDialogImage = new OpenFileDialog();
        //проверка на указание изображения
        bool BSetImages = false;
        Delivery delivery = new Delivery();
        User user = new User();
        UsersContext AllUsers = new UsersContext();
        MessagesContext AllMessages = new MessagesContext();
        public Message(Delivery _delivery, User _user)
        {
            InitializeComponent();
            delivery = _delivery;
            user = _user;
            if (user.Role == false)
            {
                foreach (User item in AllUsers.Users)
                    if (item.Id == delivery.Id_courier)
                    {
                        TbFIO.Content = item.FIO;
                        TbPhone.Content = item.Phone;
                        try
                        {
                            //BitmapImage, который будет содержать фото пользователя
                            BitmapImage biImg = new BitmapImage();
                            //открываем поток, в качестве источника указываем массив байт изображения пользователя
                            MemoryStream ms = new MemoryStream(item.Photo);
                            //сигнализируем о начале инициализации
                            biImg.BeginInit();
                            //указываем источник потока
                            biImg.StreamSource = ms;
                            //сигнализируем о конце инициализации
                            biImg.EndInit();
                            //получаем ImageSource
                            ImageSource imgSrc = biImg;
                            //устанавливаем изображение
                            IUser.Source = imgSrc;
                        }
                        catch (Exception exp)
                        {
                            //в случае возникновения ошибки, выводим в Debug
                            Debug.WriteLine(exp);
                        }
                    }
            }
            else
            {
                foreach (User item in AllUsers.Users)
                    if (item.Id == delivery.Id_customer)
                    {
                        TbFIO.Content = item.FIO;
                        TbPhone.Content = item.Phone;
                        try
                        {
                            //BitmapImage, который будет содержать фото пользователя
                            BitmapImage biImg = new BitmapImage();
                            //открываем поток, в качестве источника указываем массив байт изображения пользователя
                            MemoryStream ms = new MemoryStream(item.Photo);
                            //сигнализируем о начале инициализации
                            biImg.BeginInit();
                            //указываем источник потока
                            biImg.StreamSource = ms;
                            //сигнализируем о конце инициализации
                            biImg.EndInit();
                            //получаем ImageSource
                            ImageSource imgSrc = biImg;
                            //устанавливаем изображение
                            IUser.Source = imgSrc;
                        }
                        catch (Exception exp)
                        {
                            //в случае возникновения ошибки, выводим в Debug
                            Debug.WriteLine(exp);
                        }
                    }
            }
            foreach (Models.Message message in AllMessages.Messages)
            {
                if (message.Id_delivery == delivery.Id)
                {
                    if (message.Id_sender == user.Id)
                    {
                        Elements.ItemMessage item = new Elements.ItemMessage(message);
                        item.Margin = new Thickness(250, 10, 10, 10);
                        parent.Children.Add(item);
                    }
                    else
                    {
                        Elements.ItemMessage item = new Elements.ItemMessage(message);
                        item.Margin = new Thickness(10, 10, 250, 10);
                        parent.Children.Add(item);
                    }
                }
            }
            scroll.ScrollToBottom();
        }

        private void Back(object sender, MouseButtonEventArgs e)
        {
            if (user.Role == false)
                MainWindow.init.OpenPages(new Customer.Main());
            else
                MainWindow.init.OpenPages(new Courier.Main());
        }

        private void SendMessage(object sender, RoutedEventArgs e)
        {
            if (TextMessage.Text != "")
            {
                Models.Message mess = new Models.Message()
                {
                    Text = TextMessage.Text,
                    Date_Time = DateTime.Now,
                    Id_delivery = delivery.Id,
                    Id_sender = MainWindow.init.activeUser.Id
                };
                if (MainWindow.init.activeUser.Id != delivery.Id_courier)
                    mess.Id_recipient = delivery.Id_courier;
                else
                    mess.Id_recipient = delivery.Id_customer;
                if (BSetImages)
                    mess.Photo = File.ReadAllBytes(Directory.GetCurrentDirectory() + @"\IMessage.jpg");
                AllMessages.Messages.Add(mess);
                AllMessages.SaveChanges();
                Elements.ItemMessage item = new Elements.ItemMessage(mess);
                item.Margin = new Thickness(250, 10, 10, 10);
                parent.Children.Add(item);
                scroll.ScrollToBottom();
                TextMessage.Text = "";
                Confirm.Visibility = Visibility.Hidden;
            }
        }

        private void AddImage(object sender, RoutedEventArgs e)
        {
            //если статус диалогового окна true
            if (FileDialogImage.ShowDialog() == true)
            {
                //конвертирование размера изображения
                using (Imaging.Image image = Imaging.Image.Load(FileDialogImage.FileName))
                {
                    //ширина изображения
                    int NewWidth = 0;
                    //высота изображения
                    int NewHeight = 0;
                    //проверка сторон изображения
                    if (image.Width > image.Height)
                    {
                        //новая ширина относительно высоты
                        NewWidth = (int)(image.Width * (256f / image.Height));
                        //новая высота
                        NewHeight = 256;
                    }
                    else
                    {
                        //новая ширина
                        NewWidth = 256;
                        //новая высота относительно ширины
                        NewHeight = (int)(image.Height * (256f / image.Width));
                    }
                    //задаем новые размеры
                    image.Resize(NewWidth, NewHeight);
                    //сохранение изображения
                    image.Save("IMessage.jpg");
                }
                //обрезка изображения
                using (Imaging.RasterImage rasterImage = (Imaging.RasterImage)Imaging.Image.Load("IMessage.jpg"))
                {
                    //кэширование изображения
                    if (!rasterImage.IsCached)
                    {
                        rasterImage.CacheData();
                    }
                    //X
                    int X = 0;
                    //новая ширина
                    int Width = 256;
                    //Y
                    int Y = 0;
                    //новая высота
                    int Height = 256;
                    //если ширина больше
                    if (rasterImage.Width > rasterImage.Height)
                        //задаем X как середину
                        X = (int)((rasterImage.Width - 256f) / 2);
                    else
                        //если высота больше, задаем Y как середину
                        Y = (int)((rasterImage.Height - 256f) / 2);
                    //экземпляр Rectangle нужного размера
                    Imaging.Rectangle rectangle = new Imaging.Rectangle(X, Y, Width, Height);
                    //обрезка изображения
                    rasterImage.Crop(rectangle);
                    //сохранение
                    rasterImage.Save("IMessage.jpg");
                }
                //изображение указано
                BSetImages = true;
                Confirm.Visibility = Visibility.Visible;
            }
            else
                //изображение не указано
                BSetImages = false;
        }
    }
}
