﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using System.IO;
using System.Diagnostics;

namespace ExpressDelivery.Pages.Elements
{
    /// <summary>
    /// Логика взаимодействия для ItemMessage.xaml
    /// </summary>
    public partial class ItemMessage : UserControl
    {
        UsersContext AllUsers = new UsersContext();
        public ItemMessage(Models.Message message)
        {
            InitializeComponent();
            Image IMessage = new Image();
            TbDate.Content = message.Date_Time.ToString("dd-MM-yyyy HH:mm");
            TbMessage.Text = message.Text;
            if (message.Photo != null)
            {
                IMessage.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                IMessage.Height = 70;
                IMessage.Margin = new Thickness(10, 30, 10, 0);
                IMessage.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                IMessage.Width = 70;
                box.Children.Add(IMessage);
                try
                {
                    //BitmapImage, который будет содержать фото пользователя
                    BitmapImage biImg = new BitmapImage();
                    //открываем поток, в качестве источника указываем массив байт изображения пользователя
                    MemoryStream ms = new MemoryStream(message.Photo);
                    //сигнализируем о начале инициализации
                    biImg.BeginInit();
                    //указываем источник потока
                    biImg.StreamSource = ms;
                    //сигнализируем о конце инициализации
                    biImg.EndInit();
                    //получаем ImageSource
                    ImageSource imgSrc = biImg;
                    //устанавливаем изображение
                    IMessage.Source = imgSrc;
                }
                catch (Exception exp)
                {
                    //в случае возникновения ошибки, выводим в Debug
                    Debug.WriteLine(exp);
                }
            }
            if (message.Id_recipient == MainWindow.init.activeUser.Id)
            {
                IMessage.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                box.Background = new SolidColorBrush(Color.FromRgb(117,189,247));
            }  
        }
    }
}
