﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;

namespace ExpressDelivery.Pages.Courier
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
        public DeliveryContext AllDeliverys = new DeliveryContext();
        public Main(int index = 0)
        {
            InitializeComponent();
            Choose.SelectedIndex = index;
        }
        //открытие личного кабинета
        private void GoPersonality(object sender, MouseButtonEventArgs e)
        {
            MainWindow.init.OpenPages(new Personality());
        }

        private void ChooseDelivery(object sender, SelectionChangedEventArgs e)
        {
            parent.Children.Clear();
            if (Choose.SelectedIndex == 0)
            {
                foreach (Delivery delivery in AllDeliverys.Deliverys)
                    if (delivery.Status == "у курьера" && delivery.Id_courier == MainWindow.init.activeUser.Id)
                        parent.Children.Add(new Elements.ItemOrder(delivery));
            }
            else if (Choose.SelectedIndex == 1)
            {
                foreach (Delivery delivery in AllDeliverys.Deliverys)
                    if (delivery.Status == "ожидает доставки")
                        parent.Children.Add(new Elements.ItemOrder(delivery));
            }
            else
            {
                foreach (Delivery delivery in AllDeliverys.Deliverys)
                    if (delivery.Status == "доставлено" && delivery.Id_courier == MainWindow.init.activeUser.Id)
                        parent.Children.Add(new Elements.ItemOrder(delivery));
            }
        }
    }
}
