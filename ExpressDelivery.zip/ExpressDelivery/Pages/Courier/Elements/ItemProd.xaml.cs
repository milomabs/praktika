﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using System.IO;
using System.Diagnostics;

namespace ExpressDelivery.Pages.Courier.Elements
{
    /// <summary>
    /// Логика взаимодействия для ItemProd.xaml
    /// </summary>
    public partial class ItemProd : UserControl
    {
        Product product = new Product();
        ProductsContext AllProducts = new ProductsContext();
        DeliveryContext AllDelivery = new DeliveryContext();
        public ItemProd(Product _product)
        {
            InitializeComponent();
            product = _product;
            Delivery delivery = AllDelivery.Deliverys.Where(x => x.Id == product.Id_delivery).First();
            Comment.Content = $"Комментарий: {product.Comment}";
            Address.Content = $"Адрес доставки: {product.Address}";
            Weight.Content = $"Вес: {product.Weight} г.";
            Phone.Content = $"Номер получателя: {product.Phone_user}";
            try
            {
                //BitmapImage, который будет содержать фото пользователя
                BitmapImage biImg = new BitmapImage();
                //открываем поток, в качестве источника указываем массив байт изображения пользователя
                MemoryStream ms = new MemoryStream(product.Photo);
                //сигнализируем о начале инициализации
                biImg.BeginInit();
                //указываем источник потока
                biImg.StreamSource = ms;
                //сигнализируем о конце инициализации
                biImg.EndInit();
                //получаем ImageSource
                ImageSource imgSrc = biImg;
                //устанавливаем изображение
                IProd.Source = imgSrc;
            }
            catch (Exception exp)
            {
                //в случае возникновения ошибки, выводим в Debug
                Debug.WriteLine(exp);
            }
            if (delivery.Status == "доставлено")
                this.Status.Visibility = Visibility.Hidden;
            else if (delivery.Status == "ожидает доставки")
            {
                ready.Content = "ожидает доставки";
                this.Status.Visibility = Visibility.Hidden;
                ready.Visibility = Visibility.Visible;
            }
            ItemComboBox();
        }
        public void ItemComboBox()
        {
            if (product.Status == "ожидает доставки")
            {
                this.Status.Items.Add("ожидает доставки");
                this.Status.Items.Add("у курьера");
                this.Status.SelectedItem = "ожидает доставки";
            }
            else if (product.Status == "у курьера")
            {
                this.Status.Items.Remove("ожидает доставки");
                this.Status.Items.Add("доставлено");
                this.Status.SelectedItem = "у курьера";
            }
            else
            {
                this.Status.Visibility = Visibility.Hidden;
                ready.Visibility = Visibility.Visible;
            }
        }

        private void ChangedStatus(object sender, SelectionChangedEventArgs e)
        {
            int all = 0;
            int ready = 0;
            foreach (Product prod in AllProducts.Products)
            {
                if (prod.Id == product.Id)
                {
                    prod.Status = Status.SelectedItem.ToString();
                    product.Status = Status.SelectedItem.ToString();
                }
                if (prod.Id_delivery == product.Id_delivery)
                {
                    all++;
                    if (prod.Status == "доставлено") ready++;
                }
            }
            AllProducts.SaveChanges();
            if (all == ready)
                foreach (Delivery del in AllDelivery.Deliverys)
                {
                    if (del.Id == product.Id_delivery)
                    {
                        del.Status = "доставлено";
                        MainWindow.init.OpenPages(new Main(2));
                    }
                }
            ItemComboBox();
        }
    }
}
