﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;

namespace ExpressDelivery.Pages.Courier.Elements
{
    /// <summary>
    /// Логика взаимодействия для ItemOrder.xaml
    /// </summary>
    public partial class ItemOrder : UserControl
    {
        Delivery delivery = new Delivery();
        DeliveryContext AllDelivery = new DeliveryContext();
        ProductsContext AllProducts = new ProductsContext();
        public ItemOrder(Delivery _delivery)
        {
            InitializeComponent();
            delivery = _delivery;
            Date.Content = delivery.Date_Time.ToString("dd-MM-yyyy HH:mm");
            Address.Text = delivery.Address;
            Price.Content = delivery.Price.ToString() + " руб.";
            Status.Content = $"Статус: {delivery.Status}";
            if (delivery.Status == "ожидает доставки")
                Message.Content = "Принять заявку";
            else if (delivery.Status == "у курьера")
                Message.Content = "Написать заказчику";
            else
                Message.Content = "Посмотреть отзыв";
            foreach (Product product in AllProducts.Products)
                if (product.Id_delivery == delivery.Id)
                    parent.Children.Add(new ItemProd(product));
        }

        private void ActionCourier(object sender, RoutedEventArgs e)
        {
            if (Message.Content.ToString() == "Принять заявку")
            {
                foreach(Delivery del in AllDelivery.Deliverys)
                {
                    if (del.Id == delivery.Id)
                    {
                       del.Id_courier = MainWindow.init.activeUser.Id;
                        del.Status = "у курьера";
                    } 
                }
                AllDelivery.SaveChanges();
                MainWindow.init.OpenPages(new Main());
            }
            else if (Message.Content.ToString() == "Написать заказчику")
            {
                MainWindow.init.OpenPages(new Message(delivery, MainWindow.init.activeUser));
            }
            else
            {
                new Comment(delivery).ShowDialog();
            }
        }
    }
}
