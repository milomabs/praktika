﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;

namespace ExpressDelivery.Pages.Customer.Elements
{
    /// <summary>
    /// Логика взаимодействия для ItemProduct.xaml
    /// </summary>
    public partial class ItemProduct : UserControl
    {
        public ItemProduct(Product product)
        {
            InitializeComponent();
            try
            {
                //BitmapImage, который будет содержать фото пользователя
                BitmapImage biImg = new BitmapImage();
                //открываем поток, в качестве источника указываем массив байт изображения пользователя
                MemoryStream ms = new MemoryStream(product.Photo);
                //сигнализируем о начале инициализации
                biImg.BeginInit();
                //указываем источник потока
                biImg.StreamSource = ms;
                //сигнализируем о конце инициализации
                biImg.EndInit();
                //получаем ImageSource
                ImageSource imgSrc = biImg;
                //устанавливаем изображение
                IProd.Source = imgSrc;
            }
            catch (Exception exp)
            {
                //в случае возникновения ошибки, выводим в Debug
                Debug.WriteLine(exp);
            }
            Status.Content = product.Status;
            Comment.Content = $"Коментарий: {product.Comment}";
            Weight.Content = $"Вес: {product.Weight} г.";
            Address.Content = $"Адрес доставки: {product.Address}";
            Phone.Content = $"Номер получателя: {product.Phone_user}";
        }
    }
}
