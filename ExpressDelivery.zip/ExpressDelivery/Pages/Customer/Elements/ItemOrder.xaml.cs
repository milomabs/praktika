﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;

namespace ExpressDelivery.Pages.Customer.Elements
{
    /// <summary>
    /// Логика взаимодействия для ItemOrder.xaml
    /// </summary>
    public partial class ItemOrder : UserControl
    {
        ProductsContext AllProducts = new ProductsContext();
        Delivery this_delivery = new Delivery();
        public ItemOrder(Delivery delivery)
        {
            InitializeComponent();
            this_delivery = delivery;
            //заполняем данные доставки
            Date.Content = delivery.Date_Time.ToString("dd-MM-yyyy HH:mm");
            Address.Text = delivery.Address;
            Status.Content = $"Статус: {delivery.Status}";
            Price.Content = $"{delivery.Price} руб.";
            foreach (Product product in AllProducts.Products)
            {
                if (product.Id_delivery == delivery.Id)
                    parent.Children.Add(new ItemProduct(product));
            }
            if (delivery.Status == "ожидает доставки")
            {
                Message.Content = "Изменить";
                warning.Visibility = Visibility;
            }
            else if (delivery.Status == "у курьера")
                Message.Content = "Написать курьеру";
            else if (delivery.Comment == null)
                Message.Content = "Оставить комментарий";
            else
                Message.Content = "Изменить комментарий";
        }

        private void ActionCustomer(object sender, RoutedEventArgs e)
        {
            if (Message.Content.ToString() == "Изменить") EditOrder();
            else if (Message.Content.ToString() == "Написать курьеру") MessageCourier();
            else WriteComment();
        }
        public void EditOrder()
        {
            MainWindow.init.OpenPages(new Add(this_delivery));
        }
        public void MessageCourier()
        {
            MainWindow.init.OpenPages(new Message(this_delivery, MainWindow.init.activeUser));
        }
        public void WriteComment()
        {
            new Comment(this_delivery).ShowDialog();
        }
    }
}
