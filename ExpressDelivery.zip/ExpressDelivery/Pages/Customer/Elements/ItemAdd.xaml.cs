﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using Microsoft.Win32;
using Imaging = Aspose.Imaging;
using System.IO;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using System.Diagnostics;
using System.Linq;

namespace ExpressDelivery.Pages.Customer.Elements
{
    /// <summary>
    /// Логика взаимодействия для ItemAdd.xaml
    /// </summary>
    public partial class ItemAdd : UserControl
    {
        //файловый диалог
        OpenFileDialog FileDialogImage = new OpenFileDialog();
        //проверка на указание изображения
        bool BSetImages = false;
        Add add;
        DeliveryContext AllDelivery = new DeliveryContext();
        ProductsContext AllProducts = new ProductsContext();
        Product product = new Product();
        Delivery delivery = new Delivery();
        public ItemAdd(Delivery del, Add _add, Product _product = null)
        {
            InitializeComponent();
            delivery = del;
            add = _add;
            if (_product != null)
            {
                product = _product;
                TbAddress.Text = product.Address;
                TbAddress.IsEnabled = false;
                TbComment.Text = product.Comment;
                TbComment.IsEnabled = false;
                TbPhone.Text = product.Phone_user;
                TbPhone.IsEnabled = false;
                TbWeight.Text = product.Weight.ToString();
                TbWeight.IsEnabled = false;
                btnAdd.Content = "Изменить";
                try
                {
                    //BitmapImage, который будет содержать фото пользователя
                    BitmapImage biImg = new BitmapImage();
                    //открываем поток, в качестве источника указываем массив байт изображения пользователя
                    MemoryStream ms = new MemoryStream(product.Photo);
                    //сигнализируем о начале инициализации
                    biImg.BeginInit();
                    //указываем источник потока
                    biImg.StreamSource = ms;
                    //сигнализируем о конце инициализации
                    biImg.EndInit();
                    //получаем ImageSource
                    ImageSource imgSrc = biImg;
                    //устанавливаем изображение
                    IProd.Source = imgSrc;
                }
                catch (Exception exp)
                {
                    //в случае возникновения ошибки, выводим в Debug
                    Debug.WriteLine(exp);
                }
            }
            else
            {
                Product newproduct = new Product()
                {
                    Weight = 0,
                    Address = "",
                    Status = "ожидает доставки",
                    Id_delivery = delivery.Id
                };
                product = newproduct;
            }
        }

        private void Add_EditProd(object sender, RoutedEventArgs e)
        {
            if (btnAdd.Content.ToString() == "Изменить")
            {
                TbAddress.IsEnabled = true;
                TbComment.IsEnabled = true;
                TbPhone.IsEnabled = true;
                TbWeight.IsEnabled = true;
                btnAdd.Content = "Сохранить";
            }
            else
            {
                if (!Regex.Match(TbAddress.Text, "^[а-яА-Я0-9 \\-\\.\\,]+$").Success)
                {
                    Message.Content = "Корректно укажите адрес доставки!";
                } 
                else if (!Regex.Match(TbPhone.Text, "^(\\+7[0-9]{10}){0,1}$").Success)
                {
                    Message.Content = "Корректно укажите номер получателя!";
                } 
                else if (!Regex.Match(TbWeight.Text, "^[0-9\\.\\,]+$").Success)
                {
                    Message.Content = "Корректно укажите вес!";
                }
                else
                {
                    Message.Content = "";
                    int count = 0;
                    foreach (Product prod in AllProducts.Products)
                    {
                        if (prod.Id == product.Id)
                        {
                            count++;
                            prod.Address = TbAddress.Text;
                            prod.Comment = TbComment.Text;
                            prod.Weight = int.Parse(TbWeight.Text);
                            prod.Phone_user = TbPhone.Text;
                            if (BSetImages) prod.Photo = File.ReadAllBytes(Directory.GetCurrentDirectory() + @"\IProd.jpg");
                        }
                    }
                    if (count == 0)
                    {
                        product.Address = TbAddress.Text;
                        product.Comment = TbComment.Text;
                        product.Weight = int.Parse(TbWeight.Text);
                        product.Phone_user = TbPhone.Text;
                        if (BSetImages) product.Photo = File.ReadAllBytes(Directory.GetCurrentDirectory() + @"\IProd.jpg");
                        AllProducts.Products.Add(product);
                    }
                    AllProducts.SaveChanges();
                    TbAddress.IsEnabled = false;
                    TbComment.IsEnabled = false;
                    TbPhone.IsEnabled = false;
                    TbWeight.IsEnabled = false;
                    btnAdd.Content = "Изменить";
                    add.Price(delivery);
                }

            }
        }
        private void SelectImage(object sender, MouseButtonEventArgs e)
        {
            //если статус диалогового окна true
            if (FileDialogImage.ShowDialog() == true)
            {
                //конвертирование размера изображения
                using (Imaging.Image image = Imaging.Image.Load(FileDialogImage.FileName))
                {
                    //ширина изображения
                    int NewWidth = 0;
                    //высота изображения
                    int NewHeight = 0;
                    //проверка сторон изображения
                    if (image.Width > image.Height)
                    {
                        //новая ширина относительно высоты
                        NewWidth = (int)(image.Width * (256f / image.Height));
                        //новая высота
                        NewHeight = 256;
                    }
                    else
                    {
                        //новая ширина
                        NewWidth = 256;
                        //новая высота относительно ширины
                        NewHeight = (int)(image.Height * (256f / image.Width));
                    }
                    //задаем новые размеры
                    image.Resize(NewWidth, NewHeight);
                    //сохранение изображения
                    image.Save("IProd.jpg");
                }
                //обрезка изображения
                using (Imaging.RasterImage rasterImage = (Imaging.RasterImage)Imaging.Image.Load("IProd.jpg"))
                {
                    //кэширование изображения
                    if (!rasterImage.IsCached)
                    {
                        rasterImage.CacheData();
                    }
                    //X
                    int X = 0;
                    //новая ширина
                    int Width = 256;
                    //Y
                    int Y = 0;
                    //новая высота
                    int Height = 256;
                    //если ширина больше
                    if (rasterImage.Width > rasterImage.Height)
                        //задаем X как середину
                        X = (int)((rasterImage.Width - 256f) / 2);
                    else
                        //если высота больше, задаем Y как середину
                        Y = (int)((rasterImage.Height - 256f) / 2);
                    //экземпляр Rectangle нужного размера
                    Imaging.Rectangle rectangle = new Imaging.Rectangle(X, Y, Width, Height);
                    //обрезка изображения
                    rasterImage.Crop(rectangle);
                    //сохранение
                    rasterImage.Save("IProd.jpg");
                }
                //устанавливаем изображение
                IProd.Source = new BitmapImage(new Uri(Directory.GetCurrentDirectory() + @"\IProd.jpg"));
                //изображение указано
                BSetImages = true;
            }
            else
                //изображение не указано
                BSetImages = false;
        }

        private void Delete(object sender, RoutedEventArgs e)
        {
            foreach (Product prod in AllProducts.Products)
            {
                if (prod.Id == product.Id)
                {
                    AllProducts.Products.Remove(prod);
                } 
            }
            AllProducts.SaveChanges();
            MainWindow.init.OpenPages(new Add(AllDelivery.Deliverys.Where(x => x.Id == product.Id_delivery).First()));
        }
    }
}
