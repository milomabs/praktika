﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;

namespace ExpressDelivery.Pages.Customer
{
    /// <summary>
    /// Логика взаимодействия для Comment.xaml
    /// </summary>
    public partial class Comment : Window
    {
        Delivery delivery = new Delivery();
        DeliveryContext AllDeliverys = new DeliveryContext();
        public Comment(Delivery _delivery)
        {
            InitializeComponent();
            delivery = _delivery;
            if (delivery.Comment != null)
            {
                TbComment.Text = delivery.Comment;
                btnComment.Content = "Изменить";
            }
        }

        private void AddComment(object sender, RoutedEventArgs e)
        {
            foreach (Delivery del in AllDeliverys.Deliverys)
            {
                if(del.Id == delivery.Id)
                    del.Comment = TbComment.Text;
            }
            AllDeliverys.SaveChanges();
            this.Close();
            MainWindow.init.OpenPages(new Main());
        }
    }
}
