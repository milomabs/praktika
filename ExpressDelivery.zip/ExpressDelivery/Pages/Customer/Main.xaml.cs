﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using ExpressDelivery.Pages;

namespace ExpressDelivery.Pages.Customer
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
        //все доставки
        DeliveryContext AllDeliverys = new DeliveryContext();
        public Main()
        {
            InitializeComponent();
            //отображение истории заказов пользователя
            foreach (Delivery delivery in AllDeliverys.Deliverys)
            {
                //если код заказчика равен коду активного пользователя
                if (delivery.Id_customer == MainWindow.init.activeUser.Id)
                    parent.Children.Add(new Elements.ItemOrder(delivery));
            }
        }

        //открытие страницы для добавления заказа
        private void AddOrder(object sender, MouseButtonEventArgs e)
        {
            MainWindow.init.OpenPages(new Add());
        }

        //открытие личного кабинета
        private void GoPersonality(object sender, MouseButtonEventArgs e)
        {
            MainWindow.init.OpenPages(new Personality());
        }
    }
}
