﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using ExpressDelivery.Models;
using ExpressDelivery.Context;

namespace ExpressDelivery.Pages.Customer
{
    /// <summary>
    /// Логика взаимодействия для Add.xaml
    /// </summary>
    public partial class Add : Page
    {
        Delivery delivery = null;
        ProductsContext AllProducts = new ProductsContext();
        DeliveryContext AllDelivery = new DeliveryContext();
        public Add(Delivery _delivery = null)
        {
            InitializeComponent();
            if (_delivery != null) 
            {
                delivery = _delivery;
                delete.Visibility = Visibility;
                Title.Content = "Редактирование заказа";
                Price(delivery);
                btnAdd.Content = "Изменить";
                TbAddress.Text = delivery.Address;
                foreach (Product prod in AllProducts.Products)
                {
                    if (prod.Id_delivery == delivery.Id)
                        parent.Children.Add(new Elements.ItemAdd(delivery, this, prod));
                }
            }
            else
            {
                delivery = new Delivery()
                {
                    Address = MainWindow.init.activeUser.Address,
                    Status = "ожидает доставки",
                    Id_customer = MainWindow.init.activeUser.Id,
                    Price = 1000
                };
                AllDelivery.Deliverys.Add(delivery);
                AllDelivery.SaveChanges();
                TbAddress.Text = delivery.Address;
                Price(delivery);
            }
        }

        private void Back(object sender, MouseButtonEventArgs e)
        {
            foreach (Product prod in AllProducts.Products)
            {
                if (prod.Id_delivery == delivery.Id)
                    AllProducts.Products.Remove(prod);
            }
            AllProducts.SaveChanges();
            foreach (Delivery del in AllDelivery.Deliverys)
            {
                if (del.Id == delivery.Id)
                    AllDelivery.Deliverys.Remove(del);
            }
            AllDelivery.SaveChanges();
            MainWindow.init.OpenPages(new Main());
        }

        private void AddEdit(object sender, RoutedEventArgs e)
        {
            if (!Regex.Match(TbAddress.Text, "^[а-яА-Я0-9 \\-\\.\\,]+$").Success)
                Message.Content = "Введите адрес отправки верно!";
            else
            {
                int count = 0;
                foreach (Product prod in AllProducts.Products)
                    if (prod.Id_delivery == delivery.Id) count++;
                if (count == 0)
                {
                    Message.Content = "Укажите объекты доставки!";
                }
                else
                {
                    foreach (Delivery deliv in AllDelivery.Deliverys)
                        if (deliv.Id == delivery.Id)
                        {
                            deliv.Date_Time = DateTime.Now;
                            deliv.Address = TbAddress.Text;
                            deliv.Price = 1000 + 500 * count;
                            delivery = deliv;
                        }
                    AllDelivery.SaveChanges();
                    MainWindow.init.OpenPages(new Main());
                }
            }
        }
       
        private void AddProduct(object sender, MouseButtonEventArgs e)
        {
            parent.Children.Add(new Elements.ItemAdd(delivery, this));
            Price(delivery);
            Message.Content = "";
        }
        public void Price(Delivery del)
        {
            int count = 0;
            foreach (Product prod in AllProducts.Products)
                if (prod.Id_delivery == del.Id) count++;
            del.Price = 1000 + 500 * count;
            foreach (Delivery deli in AllDelivery.Deliverys)
                if (deli.Id == delivery.Id)
                    deli.Price = deli.Price;
            AllDelivery.SaveChanges();
            TbPrice.Content = $"Стоимость: {del.Price} руб.";
        }

        private void Delete(object sender, MouseButtonEventArgs e)
        {
            foreach (Delivery del in AllDelivery.Deliverys)
            {
                if (del.Id == delivery.Id) AllDelivery.Deliverys.Remove(del);
            }
            AllDelivery.SaveChanges();
            MainWindow.init.OpenPages(new Main());
        }
    }
}
