﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Pages.Regin;
using ExpressDelivery.Context;
using ExpressDelivery.Models;
using System.Text.RegularExpressions;
using System.Linq;

namespace ExpressDelivery.Pages
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        //список всех пользователей системы
        public UsersContext AllUsers = new UsersContext();
        public Login()
        {
            InitializeComponent();
        }

        //переход к окну регистрации
        private void Registr(object sender, MouseButtonEventArgs e)
        {
            MainWindow.init.OpenPages(new Regin_step1());
        }

        //авторизация пользователей
        private void Auth(object sender, RoutedEventArgs e)
        {
            //номер телефона из поля ввода
            string phone = TbPhone.Text;
            //проверка соответствия формату
            Match match = Regex.Match(phone, "^\\+7[0-9]{10}$");
            //сообщение об ошибке в случае не соответствия формату
            if (!match.Success)
            {
                Message.Text = "Укажите номер телефона верно!";
            }
            else
            {
                //пароль из поля ввода
                string pwd = TbPassword.Password;
                User user = null;
                //поиск пользователя по номеру телефона в БД
                foreach (User item in AllUsers.Users)
                {
                    if (item.Phone == phone) user = item;
                }
                //сообщение об ошибке в случае отсутствия номера телефона в БД 
                if (user == null)
                {
                    Message.Text = "Пользователь с таким номером не найден!";
                }
                //сообщение об ошибке в случае ввода неверного пароля
                else if (user.Password != pwd)
                {
                    Message.Text = "Пароль не верный!";
                }
                else
                {
                    MainWindow.init.activeUser = user;
                    //переход на главное окно простого пользователя
                    if(user.Role == false) MainWindow.init.OpenPages(new Customer.Main());
                    //переход на главное окно курьера
                    else MainWindow.init.OpenPages(new Courier.Main());
                }
            }
        }

        //очистка блока для вывода сообщений об ошибках
        private void Remove(object sender, MouseEventArgs e)
        {
            Message.Text = "";
        }
    }
}
