﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressDelivery.Pages;
using ExpressDelivery.Models;
using ExpressDelivery.Context;
using Microsoft.Win32;
using Imaging = Aspose.Imaging;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace ExpressDelivery.Pages
{
    /// <summary>
    /// Логика взаимодействия для Personality.xaml
    /// </summary>
    public partial class Personality : Page
    {
        //файловый диалог
        OpenFileDialog FileDialogImage = new OpenFileDialog();
        //проверка на указание изображения
        bool BSetImages = false;
        //переменная для указания редактировать данные или сохранить
        bool edit = false;
        //все пользователи системы
        UsersContext AllUsers = new UsersContext();
        //активный пользователь
        User activeUser = new User();
        public Personality()
        {
            InitializeComponent();
            FileDialogImage.Filter = "PNG (*.png)|.png|JPG (*.jpg)|*.jpg";
            //значение сохранения директории
            FileDialogImage.RestoreDirectory = true;
            //название диалогового окна
            FileDialogImage.Title = "Выберите фото";
            //задаем пользователя
            activeUser = MainWindow.init.activeUser;
            try
            {
                //BitmapImage, который будет содержать фото пользователя
                BitmapImage biImg = new BitmapImage();
                //открываем поток, в качестве источника указываем массив байт изображения пользователя
                MemoryStream ms = new MemoryStream(activeUser.Photo);
                //сигнализируем о начале инициализации
                biImg.BeginInit();
                //указываем источник потока
                biImg.StreamSource = ms;
                //сигнализируем о конце инициализации
                biImg.EndInit();
                //получаем ImageSource
                ImageSource imgSrc = biImg;
                //устанавливаем изображение
                IUser.Source = imgSrc;
            }
            catch (Exception exp)
            {
                //в случае возникновения ошибки, выводим в Debug
                Debug.WriteLine(exp);
            }
            //указываем ФИО в поле 
            TbFIO.Text = activeUser.FIO;
            //указываем номер телефона в поле 
            TbPhone.Text = activeUser.Phone;
            //указываем адрес в поле 
            TbAddress.Text = activeUser.Address;
        }

        //вернуться на главную
        private void Back(object sender, MouseButtonEventArgs e)
        {
            if (activeUser.Role == false)
                MainWindow.init.OpenPages(new Customer.Main());
            else
                MainWindow.init.OpenPages(new Courier.Main());
        }

        //изменение данных
        private void EditUser(object sender, RoutedEventArgs e)
        {
            //если данные не редактируются
            if (!edit)
            {
                //задаем переменной true, что означает редактирование данных
                edit = true;
                //меняет текст на кнопке
                EditBtn.Content = "Сохранить";
                //открываем данные для редактирования
                IUser.IsEnabled = true;
                TbFIO.IsEnabled = true;
                TbPhone.IsEnabled = true;
                TbAddress.IsEnabled = true;
            }
            //если данные редактируются
            else
            {
                //если номер телефона редактировался
                if (TbPhone.Text != activeUser.Phone)
                {
                    //проверяем номер телефона на наличие в БД
                    foreach (User user in AllUsers.Users)
                        //сообщение об ошибке в случае, если номер телефона занят другим пользователем
                        if (user.Phone == TbPhone.Text)
                        {
                            Message.Text = "Пользователь с таким номером телефона уже существует!";
                            return;
                        }
                }
                //если номер телефона не соответствует формату, сообщаем об ошибке
                if (!Regex.Match(TbPhone.Text, "^\\+7[0-9]{10}$").Success)
                    Message.Text = "Укажите номер телефона верно!";
                //если ФИО не соответствует формату, сообщаем об ошибке
                else if (!Regex.Match(TbFIO.Text, "^[а-я А-Я]+$").Success)
                    Message.Text = "Укажите ФИО верно!";
                //если ошибок не выявлено
                else
                {
                    //находим нашего пользователя
                    foreach (User user in AllUsers.Users)
                        if (user.Phone == activeUser.Phone)
                        {
                            //меняем данные
                            user.FIO = TbFIO.Text;
                            user.Phone = TbPhone.Text;
                            user.Address = TbAddress.Text;
                            //добавление фотографии пользователя, если оно указано
                            if (BSetImages)
                                user.Photo = File.ReadAllBytes(Directory.GetCurrentDirectory() + @"\IUser.jpg");
                            MainWindow.init.activeUser = user;
                            activeUser = MainWindow.init.activeUser;
                        }
                    //сохраняем изменения
                    AllUsers.SaveChanges();
                    //задаем переменной false, что означает завершение редактирования
                    edit = false;
                    //меняет текст на кнопке
                    EditBtn.Content = "Изменить";
                    //закрываем данные для редактирования
                    IUser.IsEnabled = false;
                    TbFIO.IsEnabled = false;
                    TbPhone.IsEnabled = false;
                    TbAddress.IsEnabled = false;
                }
            }
        }
        private void SelectImage(object sender, MouseButtonEventArgs e)
        {
            //если статус диалогового окна true
            if (FileDialogImage.ShowDialog() == true)
            {
                //конвертирование размера изображения
                using (Imaging.Image image = Imaging.Image.Load(FileDialogImage.FileName))
                {
                    //ширина изображения
                    int NewWidth = 0;
                    //высота изображения
                    int NewHeight = 0;
                    //проверка сторон изображения
                    if (image.Width > image.Height)
                    {
                        //новая ширина относительно высоты
                        NewWidth = (int)(image.Width * (256f / image.Height));
                        //новая высота
                        NewHeight = 256;
                    }
                    else
                    {
                        //новая ширина
                        NewWidth = 256;
                        //новая высота относительно ширины
                        NewHeight = (int)(image.Height * (256f / image.Width));
                    }
                    //задаем новые размеры
                    image.Resize(NewWidth, NewHeight);
                    //сохранение изображения
                    image.Save("IUser.jpg");
                }
                //обрезка изображения
                using (Imaging.RasterImage rasterImage = (Imaging.RasterImage)Imaging.Image.Load("IUser.jpg"))
                {
                    //кэширование изображения
                    if (!rasterImage.IsCached)
                    {
                        rasterImage.CacheData();
                    }
                    //X
                    int X = 0;
                    //новая ширина
                    int Width = 256;
                    //Y
                    int Y = 0;
                    //новая высота
                    int Height = 256;
                    //если ширина больше
                    if (rasterImage.Width > rasterImage.Height)
                        //задаем X как середину
                        X = (int)((rasterImage.Width - 256f) / 2);
                    else
                        //если высота больше, задаем Y как середину
                        Y = (int)((rasterImage.Height - 256f) / 2);
                    //экземпляр Rectangle нужного размера
                    Imaging.Rectangle rectangle = new Imaging.Rectangle(X, Y, Width, Height);
                    //обрезка изображения
                    rasterImage.Crop(rectangle);
                    //сохранение
                    rasterImage.Save("IUser.jpg");
                }
                //устанавливаем изображение
                IUser.Source = new BitmapImage(new Uri(Directory.GetCurrentDirectory() + @"\IUser.jpg"));
                //изображение указано
                BSetImages = true;
            }
            else
                //изображение не указано
                BSetImages = false;
        }

        //очитска блока для вывода сообщений об ошибках
        private void Remove(object sender, MouseEventArgs e)
        {
            Message.Text = "";
        }
    }
}
