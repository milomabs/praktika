﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ExpressDelivery.Models;
using ExpressDelivery.Classes.Common;

namespace ExpressDelivery.Context
{
    //контекст доставки
    public class DeliveryContext : DbContext
    {
        //данные из БД
        public DbSet<Delivery> Deliverys { get; set; }
        //конструктор для контекста
        public DeliveryContext() =>
            Database.EnsureCreated();
        //переопределенный метод конфигурации
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
            optionsBuilder.UseMySql(Config.ConnectionConfig, Config.Version);
    }
}
