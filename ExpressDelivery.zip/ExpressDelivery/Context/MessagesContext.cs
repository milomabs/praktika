﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ExpressDelivery.Models;
using ExpressDelivery.Classes.Common;


namespace ExpressDelivery.Context
{
    public class MessagesContext : DbContext
    {
        //данные из БД
        public DbSet<Message> Messages { get; set; }
        //конструктор для контекста
        public MessagesContext() =>
            Database.EnsureCreated();
        //переопределенный метод конфигурации
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
            optionsBuilder.UseMySql(Config.ConnectionConfig, Config.Version);
    }
}
