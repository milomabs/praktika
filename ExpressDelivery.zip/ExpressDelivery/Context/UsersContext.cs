﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ExpressDelivery.Models;
using ExpressDelivery.Classes.Common;

namespace ExpressDelivery.Context
{
    public class UsersContext : DbContext
    {
        // Данные из БД
        public DbSet<User> Users { get; set; }

        // Конструктор для контекста
        public UsersContext() =>
            Database.EnsureCreated();

        // Переопределенный метод конфигурации
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                Config.ConnectionConfig, // Строка подключения из конфигурации
                new MySqlServerVersion(new Version(8, 0, 21)), // Укажите версию вашего MySQL сервера
                options =>
                {
                    options.EnableRetryOnFailure(
                        maxRetryCount: 5, // Максимальное количество повторов
                        maxRetryDelay: TimeSpan.FromSeconds(10), // Максимальная задержка между повторами
                        errorNumbersToAdd: null // Дополнительные коды ошибок (если нужно)
                    );
                });
        }
    }
}

