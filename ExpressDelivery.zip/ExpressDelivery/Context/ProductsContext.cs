﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ExpressDelivery.Models;
using ExpressDelivery.Classes.Common;

namespace ExpressDelivery.Context
{
    public class ProductsContext : DbContext
    {
        //данные из БД
        public DbSet<Product> Products { get; set; }
        //конструктор для контекста
        public ProductsContext() =>
            Database.EnsureCreated();
        //переопределенный метод конфигурации
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
            optionsBuilder.UseMySql(Config.ConnectionConfig, Config.Version);
    }
}
