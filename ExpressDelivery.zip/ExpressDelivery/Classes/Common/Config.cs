﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace ExpressDelivery.Classes.Common
{
    //класс подключения к базе данных
    public class Config
    {
        //строка для соединения с БД
        public static string ConnectionConfig = "server=127.0.0.1;port=3306;uid=root;pwd=;database=ExDeliv;";
        //версия MySql сервера
        public static MySqlServerVersion Version = new MySqlServerVersion(new Version(8, 0, 11));
    }
}
